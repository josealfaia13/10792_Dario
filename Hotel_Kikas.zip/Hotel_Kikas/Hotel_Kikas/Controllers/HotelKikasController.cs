﻿using Hotel_Kikas.Model;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;

namespace Hotel_Kikas.Controllers
{
    [ApiController]
    [Route("/api")]
    public class HotelKikasController : Controller
    {
        [HttpGet]

        public  JsonResult reservasRequest()
        {
            var rando = new Random();
            var responses = new ReservaResult
            {
                id = 1,
                numQuarto = 112,
                nomeCliente ="Hugo",
            }; 
            return new JsonResult(responses);
        }

        [HttpPost ("CriarReserva")]

        public JsonResult CriarReserva(ReservaResult hotel)
        {
            var result = new ReservaResult
            {
                id =hotel.id,
                numQuarto = hotel.numQuarto,
                nomeCliente = hotel.nomeCliente,
            };
            return new JsonResult(Ok(result));
        }
    }
}
