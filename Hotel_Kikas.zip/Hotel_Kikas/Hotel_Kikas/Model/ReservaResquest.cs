﻿namespace Hotel_Kikas.Model
{
    public class ReservaResquest
    {
        public int id { get; set; }

        public int numQuarto { get; set; }

        public string? nomeCliente { get; set; }
    }
}
